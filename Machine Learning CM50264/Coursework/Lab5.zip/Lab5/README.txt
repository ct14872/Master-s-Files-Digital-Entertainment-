Implementations are in separate .ipynb files, and are named respectively of the algorithms in each.

To run please open Jupyter. Please do not restart and run all cells as there are 
some that perform hyperparameter tuning and take a very long time to finish.

The toy problem dataset is included in the toy.zip.

Each cell has comments to explain what the code does.

The report is named as MLreport.pdf and there is an extras.pdf with extra information about kNN 
and Linear regression which were omitted from the report to save space. Please do not grade this
and only consider this as extra.

Thank you very much.
